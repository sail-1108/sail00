//db.js
module.exports = {
    mysql: {
        host: '127.0.0.1', //mysql连接ip地址
        user: 'root',
        password: '123456', //mySql用户名密码
        database: 'student',
        port: '3306' //mysql连接端口
    }
}
